"""Debatecord Discord bot package."""

